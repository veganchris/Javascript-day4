
let cararr = [];
let gallery = document.getElementById("container");
class cars {
    constructor(image, brand, type, price, age, desc) {
        this.image = image;
        this.brand = brand;
        this.type = type;
        this.price = price;
        this.age = age;
        this.desc = desc;

        cararr.push(this);
    }
}

const car1 = new cars("https://images.pexels.com/photos/116675/pexels-photo-116675.jpeg?auto=compress&cs=tinysrgb&w=400", "Range Rover", "Sport", "51200", 1, "almost new")
const car2 = new cars("https://images.pexels.com/photos/225841/pexels-photo-225841.jpeg?auto=compress&cs=tinysrgb&w=400", "Range Rover", "Discovery", "43300", 3, "you need this")
const car3 = new cars("https://images.pexels.com/photos/11952741/pexels-photo-11952741.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1", "Hyundai", "I30 CX", "6000", 10, "nonsmoker")
const car4 = new cars("https://images.pexels.com/photos/1035108/pexels-photo-1035108.jpeg?auto=compress&cs=tinysrgb&w=400", "Audi", "Q5", "66400", 5, "2.0L, 220PS")
const car5 = new cars("https://images.pexels.com/photos/446389/pexels-photo-446389.jpeg?auto=compress&cs=tinysrgb&w=400", "Mercedes", "300", "21100", 15, "a classical")
const car6 = new cars("https://images.pexels.com/photos/16896047/pexels-photo-16896047/free-photo-of-nacht-auto-fahrzeug-vintage.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1", "Opel", "Vectra", "15000", 6, "from Germany")
let i=0;
// for (let model of cararr) {
    for(let i = 0; i < cararr.length; i++){
    // let pictclick = "pictclick" + i;
    gallery.innerHTML +=
        `
        <div class="card" style="width: 18rem;">
            <img src="${cararr[i].image}" id="pictclick" class="card-img-top h-50" alt="...">
            <div class="card-body align-content-end">
                <h1 class="card-title">${cararr[i].brand}</h1>
                <h3 class="card-title">${cararr[i].type}</h3>
                <p class="card-text">Years: ${cararr[i].age}, Price: ${cararr[i].price} €"</p>
            </div>
        </div>
        `
       
    document.getElementById('pictclick').addEventListener("click", () => {
        document.getElementById("bigcontainer").style.display = "block";
        document.getElementById("bigcontainer").innerHTML = ` <img src="${cararr[i].image}">`;
        
    })
    // i++;
}
